//Mateusz Jachna - 3
import java.util.Scanner;
public class Source{
    static int s(int T[],int k) {
        if (T.length<20) {
            Sort(T, 0, T.length);
            if(k==0) return T[0];
            return T[k - 1];
        }else{
            int K=4,P=0,i=(int)Math.ceil(T.length/5);
            int M[]=new int[i];
            for(i=0;i<M.length;i++){
                if(K>T.length)K=T.length;
                if(P>=K)break;
                M[i]=Sort(T,P,K);
                P=K+1;K+=5;
            }
            int m=s(M,M.length/2);
            int Z=0,X=0,C=0;
            for (i=0;i<T.length;i++){
                if(T[i]<m)Z++;
                else if(T[i]>m)X++;
                else C++;
            }
            if(Z>=k){
                i=0;
                int q[]=new int[Z];
                for(int j=0;j<T.length;j++){
                    if(T[j]<m){
                        q[i]=T[j];
                        i++;
                    }
                }
                return s(q,k);
            } else if (Z+C>=k)return m;
            else {
                i=0;
                int q[]=new int[X];
                for (int j=0;j<T.length;j++){
                    if(T[j]>m){
                        q[i]=T[j];
                        i++;
                    }
                }
                return s(q,k-Z-C);
            }
        }
    }
    static int Sort(int tab[],int p,int k){
        for(int i=p;i<k;i++){
            for(int j=p;j<k-1;j++){
                if(tab[i]<tab[j]){
                    int temp=tab[i];
                    tab[i]=tab[j];
                    tab[j]=temp;
                }
            }
        }
        return tab[p+((k-p)/2)];
    }
    public static void main(String[] args){
        Scanner n=new Scanner(System.in);
        int iz=n.nextInt(),S;
        while (iz-->0){
            int s=n.nextInt();
            int T[]=new int[s];
            for (int i=0;i<s;i++)T[i]=n.nextInt();
            s=n.nextInt();
            for (int i=0;i<s;i++){
                S=n.nextInt();
                System.out.println(S+" "+s(T,S));
            }
        }
    }
}
